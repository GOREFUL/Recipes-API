﻿using MediatR;

namespace Recipes.Application.Users.Queries.GetCurrentUserId;
public class GetCurrentUserIdQuery : IRequest<Guid?>
{

}
