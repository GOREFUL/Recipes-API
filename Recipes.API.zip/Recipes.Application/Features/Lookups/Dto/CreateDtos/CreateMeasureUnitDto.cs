﻿namespace Recipes.Application.Features.Lookups.Dto.CreateDtos;
public class CreateMeasureUnitDto
{
    public string Name { get; set; } = default!;
}
