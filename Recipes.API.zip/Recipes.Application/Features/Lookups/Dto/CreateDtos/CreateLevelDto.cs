﻿namespace Recipes.Application.Features.Lookups.Dto.CreateDtos;
public class CreateLevelDto
{
    public string Name { get; set; } = default!;
}
