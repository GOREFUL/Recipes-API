﻿namespace Recipes.Application.Features.Lookups.Dto.CreateDtos;
public class CreateCuisineDto
{
    public string Name { get; set; } = default!;
}
