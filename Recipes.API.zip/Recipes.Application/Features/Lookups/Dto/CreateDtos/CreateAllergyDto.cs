﻿namespace Recipes.Application.Features.Lookups.Dto.CreateDtos;
public class CreateAllergyDto
{
    public string Name { get; set; } = default!;
}
