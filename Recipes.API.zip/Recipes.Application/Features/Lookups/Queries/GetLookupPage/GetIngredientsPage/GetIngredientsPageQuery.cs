﻿using MediatR;
using Recipes.Application.Features.Lookups.Dto.Lookup;

namespace Recipes.Application.Features.Lookups.Queries.GetLookupPage.GetIngredientsPage;
public record GetIngredientsPageQuery(string? Q, int Page = 1, int PageSize = 20) 
    : IRequest<Paged<LookupItemDto>>;
