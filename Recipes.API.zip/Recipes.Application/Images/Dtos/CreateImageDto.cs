﻿namespace Recipes.Application.Images.Dtos;
public class CreateImageDto
{
    public string Url { get; set; } = default!;
}
